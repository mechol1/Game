package MyGame;

import basicgraphics.*;
import basicgraphics.images.Picture;

import java.awt.*;
import java.awt.image.BufferedImage;


public class Enemies extends Sprite {
    public static Picture ufo;
    public static Picture monster;
    public static Picture ufoMk2;
    public static Picture monsterMk2;
    public static Picture boss;
    public static Picture f1;
    public static Picture f2;
    public static Picture f3;
    public static Picture f4;
    public static Picture f5;
    public static Picture f6;
    public static Picture f7;
    public static Picture f8;
    public static Picture f9;
    public static Picture f10;
    public static Picture f11;
    public static Picture black;


    public boolean fUfoDead = false;

    public  boolean ufoDead = false;
    public boolean bossDead = false;
    Player p;

    static int enemyCount;

    @Override
    public void setActive(boolean b) {
        if(isActive() == b)
            return;
        if(b == true)
            enemyCount++;
        else
            enemyCount--;
        super.setActive(b);
    }
    public Enemies(SpriteComponent sc, Player p) {
        super(sc);
        this.p = p;

        f1 = new
                Picture("frame0005.png");
        f2 = new
                Picture("frame0010.png");
        f3 = new
                Picture("frame0015.png");
        f4 = new
                Picture("frame0020.png");
        f5 = new
                Picture("frame0025.png");
        f6 = new
                Picture("frame0030.png");
        f7 = new
                Picture("frame0035.png");
        f8 = new
                Picture("frame0050.png");
        f9 = new
                Picture("frame0055.png");
        f10 = new
                Picture("frame0060.png");
        f11 = new
                Picture("frame0065.png");

        BufferedImage bf = BasicFrame.createImage(50, 50);
        Graphics2D g = (Graphics2D) bf.getGraphics();
        g.setColor(Color.black);
        g.fillOval(0, 0, 50, 50);
        black = new Picture(bf);
    }

    public static class UFO extends Enemies {

        public void shoot() {
            Bullets.Plasma b = new Bullets.Plasma(getSpriteComponent());
            b.setVelX(0);
            b.setVelY(10);
            b.setCenterX(centerX());
            b.setCenterY(centerY());
        }
        public UFO(SpriteComponent sc, Player p) {
            super(sc, p);
            BufferedImage bf = BasicFrame.createImage(50, 50);
            Graphics2D g = (Graphics2D) bf.getGraphics();
            int H = bf.getHeight();
            int W = bf.getWidth();
            g.setColor(Color.PINK);
            g.drawOval(10, 0, W - 30, 20);
            g.fillOval(0, H - 40, W - 10, H - 40);
            g.drawOval(0, H - 40, W - 10, H - 40);
            ufo = new Picture(bf);
            setPicture(ufo);
            setX(W / 2);
            setY(H / 2);
            setVelX(3);
            Task Shoot = new Task() {
                @Override
                public void run() {
                    if (ufoDead == true) {
                        return;
                    }
                    if (iteration() % 100 == 1) {
                        shoot();
                    }
                }
            };
            Clock.addTask(Shoot);
        }
    }
        @Override
        public void processEvent(SpriteCollisionEvent se) {
            SpriteComponent sc = getSpriteComponent();
            if (se.eventType == CollisionEventType.WALL_INVISIBLE) {
                if (se.xlo) {
                    setVelX(Math.abs(getVelX()));
                }
                if (se.xhi) {
                    setVelX(Math.abs(getVelX()) * -1);
                }
                if (se.ylo) {
                    setY(sc.getSize().height - getHeight());
                }
                if (se.yhi) {
                    setY(0);
                }
            }
        }

        public static class Monster extends Enemies {


            public Monster(SpriteComponent sc, Player p) {
                super(sc, p);
                monster = new Picture("monster.gif");
                setPicture(monster.resize(.20));
                setVelX(-8);
            }

            @Override
            public void processEvent(SpriteCollisionEvent se) {
                SpriteComponent sc = getSpriteComponent();
                if (se.eventType == CollisionEventType.WALL_INVISIBLE) {
                    if (se.xlo) {
                        setVelX(Math.abs(getVelX()));
                        setY(getY()+20);
                    }
                    if (se.xhi) {
                        setVelX(Math.abs(getVelX()) * -1);
                        setY(getY() + 20);
                    }
                    if (se.ylo) {
                        setY(sc.getSize().height - getHeight());
                    }
                    if (se.yhi) {
                        setY(0);
                    }
                }
            }
        }

        public static class MonsterMk2 extends Enemies {

            public MonsterMk2(SpriteComponent sc, Player p) {
                super(sc, p);
                monsterMk2 = new Picture("monsterMk2.png");
                setPicture(monsterMk2.resize(.1));
                setVelX(15);

            }

            @Override
            public void processEvent(SpriteCollisionEvent se) {
                SpriteComponent sc = getSpriteComponent();
                if (se.eventType == CollisionEventType.WALL_INVISIBLE) {
                    if (se.xlo) {
                        setVelX(Math.abs(getVelX()));
                        setY(getY() + 40);
                    }
                    if (se.xhi) {
                        setVelX(Math.abs(getVelX()) * -1);
                        setY(getY() + 40);
                    }
                    if (se.ylo) {
                        setY(sc.getSize().height - getHeight());
                    }
                    if (se.yhi) {
                        setY(0);
                    }
                }
            }
        }

        public static class FastUfo extends Enemies{
            public void shoot() {
                Bullets.Plasma b = new Bullets.Plasma(getSpriteComponent());
                b.setVelX(0);
                b.setVelY(20);
                b.setCenterX(centerX());
                b.setCenterY(centerY());
            }

                public FastUfo(SpriteComponent sc, Player p){

                        super(sc, p);
                        BufferedImage bf = BasicFrame.createImage(50, 50);
                        Graphics2D g = (Graphics2D) bf.getGraphics();
                        int H = bf.getHeight();
                        int W = bf.getWidth();
                        g.setColor(Color.RED);
                        g.drawOval(10, 0, W - 30, 20);
                        g.fillOval(0, H - 40, W - 10, H - 40);
                        g.drawOval(0, H - 40, W - 10, H - 40);
                        ufoMk2 = new Picture(bf);
                        setPicture(ufoMk2);
                        setX(W / 2);
                        setY(H / 2);
                        setVelX(6);
                        Task Shoot = new Task() {
                            @Override
                            public void run() {
                                if (fUfoDead == true) {
                                    return;
                                }
                                if (iteration() % 50 == 1) {
                                    shoot();
                                }
                            }
                        };
                        Clock.addTask(Shoot);

                }
        }

        public static class Boss extends Enemies {
            public void shoot() {
                Bullets.BigBullet b = new Bullets.BigBullet(getSpriteComponent());
                b.setVelX(0);
                b.setVelY(20);
                b.setCenterX(centerX());
                b.setCenterY(centerY());
            }

            public Boss(SpriteComponent sc, Player p) {
                super(sc, p);
                boss = new Picture("boss.png");
                setPicture(boss.resize(.25));
                setVelX(.75);
                Task Shoot = new Task() {
                    @Override
                    public void run() {
                        if (bossDead == true) {
                            return;
                        }
                        if (iteration() % 50 == 1) {
                            shoot();
                        }
                    }
                };
            }

            @Override
            public void processEvent(SpriteCollisionEvent se) {
                SpriteComponent sc = getSpriteComponent();
                if (se.eventType == CollisionEventType.WALL_INVISIBLE) {
                    if (se.xlo) {
                        setVelX(Math.abs(getVelX()));
                        setY(getY() + 40);
                    }
                    if (se.xhi) {
                        setVelX(Math.abs(getVelX()) * -1);
                        setY(getY() + 40);
                    }
                    if (se.ylo) {
                        setY(sc.getSize().height - getHeight());
                    }
                    if (se.yhi) {
                        setY(0);
                    }
                }
            }
        }
}

