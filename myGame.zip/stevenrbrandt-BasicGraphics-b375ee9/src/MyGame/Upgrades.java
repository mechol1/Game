package MyGame;

import basicgraphics.Sprite;
import basicgraphics.SpriteComponent;
import basicgraphics.images.Picture;

public class Upgrades extends Sprite {

    Picture p = new Picture("arrow.png");

    public Upgrades(SpriteComponent sc){
        super(sc);
        setPicture(p.resize(.05));
    }


}
