package MyGame;

import basicgraphics.*;
import basicgraphics.images.Picture;
import basicgraphics.sounds.ReusableClip;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.util.Random;
import javax.swing.*;


/**
     * This program is a game that displays a spaceship.
     * The spaceship shoots with a press of the spacebar.
     * Shoot to kill enemies.
     * To run the game simply run the main method in this class.
     * @author Mark Echols
     */
    public class Armageddon {

    static int enemiesKilled = 0;
        public static boolean UpgradeOn = false;


        public static void level2(SpriteComponent sc, Player p){
                    Dimension d = sc.getSize();


                    Enemies.Monster m = new Enemies.Monster(sc, p);
                    m.setX(d.width / 3);
                    m.setY(d.height - 350);

                    Enemies.MonsterMk2 k = new Enemies.MonsterMk2(sc, p);

                    Enemies.FastUfo fastUfo = new Enemies.FastUfo(sc, p);

                    Enemies.UFO u = new Enemies.UFO(sc, p);
                    u.setX(d.width/2);
                    u.setY(d.height-400);

                    Enemies.UFO u1 = new Enemies.UFO(sc, p);
                    u1.setX((d.width/2) + 100);
                    u1.setY((d.height - 200));

                    Enemies.UFO u2 = new Enemies.UFO(sc, p);
                    u2.setX((d.width/2) + 50);
                    u1.setY((d.height-400));
                }


        public static void level3(SpriteComponent sc, Player p){

            Dimension d = sc.getSize();

            Enemies.Monster m = new Enemies.Monster(sc, p);
            m.setX(d.width / 2 + 100);
            m.setY(d.height -380);
            m.setVelX(m.getVelX() * -1);

            Enemies.Monster m1 = new Enemies.Monster(sc, p);
            m1.setX(d.width / 3 + 90);
            m1.setY(d.height - 350);

            Enemies.Monster m2 = new Enemies.Monster(sc, p);
            m2.setX(d.width / 3 + 100);
            m2.setY(d.height - 320);
            m2.setVelX(m2.getVelX() * -1);

            Enemies.Monster m3 = new Enemies.Monster(sc, p);
            m3.setX(d.width / 3);
            m3.setY(d.height - 290);

            Enemies.Monster m4 = new Enemies.Monster(sc, p);
            m4.setX(d.width / 3 + 50);
            m4.setY(d.height - 290);
        }



        public static void level4(SpriteComponent sc, Player p){

            Dimension d = sc.getSize();

            Enemies.MonsterMk2 monsterMk2 = new Enemies.MonsterMk2(sc, p);

            Enemies.MonsterMk2 monsterMk2_1 = new Enemies.MonsterMk2(sc, p);
            monsterMk2_1.setX(d.width/2);

            Enemies.MonsterMk2 monsterMk2_2 = new Enemies.MonsterMk2(sc, p);
            monsterMk2_2.setX(d.width / 2 + 200);

            Enemies.MonsterMk2 monsterMk2_3 = new Enemies.MonsterMk2(sc, p);
            monsterMk2_3.setY(d.height - 290);
        }

        public static void level5(SpriteComponent sc, Player p){
            Enemies.Boss b = new Enemies.Boss(sc, p);
        }

        public static void main(String[] args) throws IOException {
            final ReusableClip clip = new ReusableClip("beep.wav");
            final BasicFrame bf = new BasicFrame("Armageddon");
            final Container content = bf.getContentPane();
            final CardLayout cards = new CardLayout();
            Picture a = new Picture("arrow.png");
            content.setLayout(cards);
            BasicContainer bc1 = new BasicContainer();
            content.add(bc1,"Splash");
            final BasicContainer bc2 = new BasicContainer();
            content.add(bc2,"Game");

            final SpriteComponent sc = new SpriteComponent() {
                int count = 0;
                @Override
                public void paintBackground(Graphics g) {
                    Random rand = new Random(count++/10);
                    // Java 'Color' class takes 3 floats, from 0 to 1.
                    float r = rand.nextFloat();
                    float gr = rand.nextFloat();
                    float b = rand.nextFloat();
                    Color randomColor = new Color(r, gr, b);
                    Dimension d = getSize();
                    g.setColor(Color.black);
                    Random rand2 = new Random(count++/50);
                    g.fillRect(0, 0, d.width, d.height);
                    final int NUM_STARS = 30;
                    //Random rand = new Random();
                    rand.setSeed(0);
                    g.setColor(randomColor);
                    for(int i=0;i<NUM_STARS;i++) {
                        int diameter = rand2.nextInt(5);
                        int xpos = rand2.nextInt(d.width);
                        int ypos = rand2.nextInt(d.height);
                        g.fillOval(xpos, ypos, diameter, diameter);

                    }


                }
            };
            sc.setPreferredSize(new Dimension(800,400));

            String[][] splashLayout = {
                    {"Title"},
                    {"Button"}
            };
            bc1.setStringLayout(splashLayout);
            bc1.add("Title",new JLabel("Shooter"));
            JButton jstart = new JButton("Start");
            jstart.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    cards.show(content,"Game");
                    // The BasicContainer bc2 must request the focus
                    // otherwise, it can't get keyboard events.
                    bc2.requestFocus();

                    // Start the timer
                    Clock.start(10);
                }
            });
            bc1.add("Button",jstart);
            String[][] layout = {{
                    "Shooter"
            }};
            bc2.setStringLayout(layout);
            bc2.add("Shooter",sc);
            bf.show();
            final Player f = new Player(sc);
            Enemies.UFO e = new Enemies.UFO(sc, f);
            Enemies.UFO e2 = new Enemies.UFO(sc, f);
            Enemies.Monster m = new Enemies.Monster(sc, f);

            Dimension d = sc.getSize();
            e2.setX(d.width*-1/2);
            e2.setY(d.height + 100);
            m.setX(d.width/3);
            m.setY(d.height - 350);
            //final double INCR = Math.PI*2/100.0;
            // Note: Adding the listener to basic container 2.
            bc2.addKeyListener(new KeyAdapter() {
                @Override
                public void keyPressed(KeyEvent ke) {
                    if (ke.getKeyCode() == KeyEvent.VK_RIGHT) {
                        f.setVelX(4.0);
                    } else if (ke.getKeyCode() == KeyEvent.VK_LEFT) {
                        f.setVelX(-4.0);
                    } else if (ke.getKeyChar() == ' ') {
                        Bullets.PlayerBullet pl = new Bullets.PlayerBullet(sc);
                        pl.setCenterX(f.centerX());
                        pl.setCenterY(f.centerY());
                        clip.play();
                    }
                }
                    @Override
                    public void keyReleased(KeyEvent c){
                        if(c.getKeyChar() == ' '){
                            return;
                        }
                        f.setVelX(f.getVelX());
                    }


            });

            sc.addSpriteSpriteCollisionListener(Enemies.class, Bullets.PlayerBullet.class,
                    (Enemies sp1, Bullets.PlayerBullet sp2) -> {
                sp1.ufoDead = true;
                sp1.fUfoDead = true;
                        Task t = new Task() {
                            @Override
                            public void run() {

                                if(iteration() < 10) {
                                    sp1.setPicture(Enemies.f1);
                                }
                                if(iteration() < 30) {
                                    sp1.setPicture(Enemies.f2);
                                }
                                if(iteration() < 50) {
                                    sp1.setPicture(Enemies.f3);
                                }
                                if(iteration() < 70) {
                                    sp1.setPicture(Enemies.f4);
                                }
                                if(iteration() < 90) {
                                    sp1.setPicture(Enemies.f5);
                                }
                                if(iteration() < 110){
                                    sp1.setPicture(Enemies.f6);
                                }
                                if(iteration() < 130){
                                    sp1.setPicture(Enemies.f7);
                                }
                                if(iteration() < 150){
                                    sp1.setPicture(Enemies.f8);
                                }
                                if(iteration() < 170){
                                    sp1.setPicture(Enemies.f9);
                                }
                                if(iteration() < 190){
                                    sp1.setPicture(Enemies.f10);
                                }
                                if(iteration() < 210){
                                    sp1.setPicture(Enemies.f11);

                                }
                            }
                        };

                    Clock.addTask(t);

                        Task nxtLvl = new Task(0) {
                            @Override
                            public void run() {
                                sp1.setActive(false);

                                if(enemiesKilled == 3 ){
                                 //  if(iteration() > 40) {
                                       level2(sc, f);
                                 //  }
                                }

                                if(enemiesKilled == 9 ){
                                    level3(sc, f);
                                }
                                if(enemiesKilled ==14){
                                    level4(sc, f);
                                }
                                if(enemiesKilled == 18){
                                    level5(sc, f);
                                }
                            }
                        };
                    sp1.setActive(false);
                    sp2.setActive(false);
                        if(!sp1.isActive()){
                            enemiesKilled++;
                        }
                   if(sp1.equals(m)){
                       if(!m.isActive()) {
                           Upgrades u1 = new Upgrades(sc);
                           u1.setX(m.getX());
                           u1.setY(m.getY());
                           u1.setVelX(0);
                           u1.setVelY(3);
                       }


                    }
                        Clock.addTask(nxtLvl);
            });

            sc.addSpriteSpriteCollisionListener(Enemies.class, Player.class,
                    (Enemies sp1, Player sp2) -> {
                        Task p = new Task() {
                            @Override
                            public void run() {
                                if(iteration() < 10) {
                                    sp1.setPicture(Enemies.f1);
                                }
                                if(iteration() < 30) {
                                    sp1.setPicture(Enemies.f2);
                                }
                                if(iteration() < 50) {
                                    sp1.setPicture(Enemies.f3);
                                }
                                if(iteration() < 70) {
                                    sp1.setPicture(Enemies.f4);
                                }
                                if(iteration() < 90) {
                                    sp1.setPicture(Enemies.f5);
                                }
                                if(iteration() < 110){
                                    sp1.setPicture(Enemies.f6);
                                }
                                if(iteration() < 130){
                                    sp1.setPicture(Enemies.f7);
                                }
                                if(iteration() < 150){
                                    sp1.setPicture(Enemies.f8);
                                }
                                if(iteration() < 170){
                                    sp1.setPicture(Enemies.f9);
                                }
                                if(iteration() < 190){
                                    sp1.setPicture(Enemies.f10);
                                }
                                if(iteration() < 210){
                                    sp1.setPicture(Enemies.f11);
                                    sp1.setActive(false);
                                    sp2.setActive(false);
                                }
                            }
                        };
                        Clock.addTask(p);

                        GameOver g = new GameOver(sc);
                        g.setY(d.height/8);
                        g.setX(200);
                    });

            sc.addSpriteSpriteCollisionListener(Upgrades.class, Player.class,
                    (Upgrades sp1, Player sp2) ->{
                        sp1.setActive(false);
                        Task upgrade = new Task(){
                            @Override
                            public void run(){
                                if(iteration() < 100){
                                    UpgradeOn = true;
                                }
                            }
                        };
                        Clock.addTask(upgrade);
                    });

            sc.addSpriteSpriteCollisionListener(Enemies.MonsterMk2.class, Player.class,
                    (Enemies.MonsterMk2 sp1, Player sp2) ->{
                        sp1.setActive(false);
                        sp2.setActive(false);
                        GameOver g = new GameOver(sc);
                        g.setY(d.height/8);
                        g.setX(200);
                    });

//            sc.addSpriteSpriteCollisionListener(Enemies.UFO.class, Bullets.PlayerBullet.class,
//                    (Enemies.UFO sp1, Bullets.PlayerBullet sp2) ->{
//                            sp1.setActive(false);
//                    });

            sc.addSpriteSpriteCollisionListener(Bullets.Plasma.class, Player.class,//collision w enemy  bullet & player
                    (Bullets.Plasma sp1, Player sp2) ->{
                       sp1.setActive(false);
                       sp2.setActive(false);
                        Task explode = new Task() {
                            @Override
                            public void run() {
                                if(iteration() < 10) {
                                    sp1.setPicture(Enemies.f1);
                                }
                                if(iteration() < 30) {
                                    sp1.setPicture(Enemies.f2);
                                }
                                if(iteration() < 50) {
                                    sp1.setPicture(Enemies.f3);
                                }
                                if(iteration() < 70) {
                                    sp1.setPicture(Enemies.f4);
                                }
                                if(iteration() < 90) {
                                    sp1.setPicture(Enemies.f5);
                                }
                                if(iteration() < 110){
                                    sp1.setPicture(Enemies.f6);
                                }
                                if(iteration() < 130){
                                    sp1.setPicture(Enemies.f7);
                                }
                                if(iteration() < 150){
                                    sp1.setPicture(Enemies.f8);
                                }
                                if(iteration() < 170){
                                    sp1.setPicture(Enemies.f9);
                                }
                                if(iteration() < 190){
                                    sp1.setPicture(Enemies.f10);
                                }
                                if(iteration() < 210){
                                    sp1.setPicture(Enemies.f11);
                                    sp1.setActive(false);
                                    sp2.setActive(false);
                                }
                            }
                        };
                        Clock.addTask(explode);
                        GameOver g = new GameOver(sc);
                        g.setY(d.height/8);
                        g.setX(200);
                    });



            sc.addSpriteSpriteCollisionListener(Enemies.Boss.class, Bullets.PlayerBullet.class,
                        (Enemies.Boss sp1, Bullets.PlayerBullet sp2) ->{

                        int hp = 30;

                        sp2.setActive(false);

                        if(!sp2.isActive()){
                            hp--;
                        }

                        if(hp == 0){
                            sp1.setActive(false);
                        }
                            Task explode = new Task() {
                                @Override
                                public void run() {
                                    if (iteration() < 10) {
                                        sp1.setPicture(Enemies.f1);
                                    }
                                    if (iteration() < 30) {
                                        sp1.setPicture(Enemies.f2);
                                    }
                                    if (iteration() < 50) {
                                        sp1.setPicture(Enemies.f3);
                                    }
                                    if (iteration() < 70) {
                                        sp1.setPicture(Enemies.f4);
                                    }
                                    if (iteration() < 90) {
                                        sp1.setPicture(Enemies.f5);
                                    }
                                    if (iteration() < 110) {
                                        sp1.setPicture(Enemies.f6);
                                    }
                                    if (iteration() < 130) {
                                        sp1.setPicture(Enemies.f7);
                                    }
                                    if (iteration() < 150) {
                                        sp1.setPicture(Enemies.f8);
                                    }
                                    if (iteration() < 170) {
                                        sp1.setPicture(Enemies.f9);
                                    }
                                    if (iteration() < 190) {
                                        sp1.setPicture(Enemies.f10);
                                    }
                                    if (iteration() < 210) {
                                        sp1.setPicture(Enemies.f11);
                                        sp1.setActive(false);
                                        sp2.setActive(false);
                                    }
                                }
                            };
                            Clock.addTask(explode);
                            Win w = new Win(sc);
                        });

            sc.addSpriteSpriteCollisionListener(Enemies.UFO.class, Enemies.UFO.class,//ufo will bounce off other ufo
                        (Enemies.UFO sp1, Enemies.UFO sp2) ->{
                            sp1.setVelX(sp1.getVelX() * -1);
                            sp2.setVelX(sp2.getVelX() * -1);
                        });

            sc.addSpriteSpriteCollisionListener(Enemies.class, Enemies.class,
                        (Enemies sp1, Enemies sp2) ->{
                            sp1.setVelX(sp1.getVelX() * -1);
                            sp2.setVelX(sp2.getVelX() * -1);
                        });

            Clock.addTask(sc.moveSprites());
        }

    }


