package MyGame;

import basicgraphics.Sprite;
import basicgraphics.SpriteComponent;
import basicgraphics.images.Picture;

public class Win extends Sprite {
    public Picture w = new Picture("win.png");
    public Win(SpriteComponent sc){
            super(sc);
            setPicture(w);
    }
}
