
package MyGame;

import basicgraphics.*;
import basicgraphics.images.Picture;

import java.awt.*;
import java.awt.image.BufferedImage;

import static MyGame.Armageddon.UpgradeOn;

public class Bullets extends Sprite {

    public static Picture redLaser;
    public static Picture laser;

    /**
     * Just sets the picture.
     *
     * @param sc
     */
    public Bullets(SpriteComponent sc){
        super(sc);



    }
    public static class Plasma extends Bullets{
        public Plasma(SpriteComponent sc){
            super(sc);
            Picture plasma;
            BufferedImage bf = BasicFrame.createImage(10, 10);
            Graphics2D g = (Graphics2D) bf.getGraphics();
            g.setColor(Color.white);
            g.fillOval(0, 0, 10, 10);
            plasma = new Picture(bf);
            setPicture(plasma);
        }
    }
    public static class BigBullet extends Bullets {
        Picture redLaser = new Picture("laserRed.png");

        public BigBullet(SpriteComponent sc) {
            super(sc);
            Picture bb;
            BufferedImage bf = BasicFrame.createImage(10, 40);
            Graphics2D g = (Graphics2D) bf.getGraphics();
            g.setColor(Color.white);
            g.fillOval(0, 0, 10, 40);
            bb = new Picture(bf);
            setPicture(bb);
        }

        /**
         * Disappears if it comes in contact with the display boundary.
         *
         * @param se
         */
        @Override
        public void processEvent(SpriteCollisionEvent se) {
            setActive(false);
        }
    }

    public static class PlayerBullet extends Bullets{
        public PlayerBullet(SpriteComponent sc){
            super(sc);
            laser = new Picture("laser.png");
            setPicture(laser.resize(.1));
            setVelY(-6);
            redLaser = new Picture("laserRed.png");
            Task t = new Task() {
                @Override
                public void run() {
                    if(UpgradeOn) {
                        setPicture(redLaser);
                        setVelY(-20);
                        setCenterX(centerX());
                        setCenterY(centerY());
                    }
                }
            };
            Clock.addTask(t);
        }
    }
    }

