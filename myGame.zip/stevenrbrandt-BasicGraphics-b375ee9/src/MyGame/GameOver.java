package MyGame;


import basicgraphics.Sprite;
import basicgraphics.SpriteComponent;
import basicgraphics.images.Picture;


public class GameOver extends Sprite {
    Picture go = new Picture("gameover.png");
    public GameOver(SpriteComponent sc){
        super(sc);
        setPicture(go.resize(.5));
    }
}
