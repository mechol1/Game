package MyGame;


import basicgraphics.*;
import basicgraphics.images.Picture;

import java.awt.*;

/**
 *
 * @author sbrandt
 */
public class Player extends Sprite {
    public Picture initialPic;

    /**
     * Initializes the sprite, setting its picture,
     * position, and speed. It also adds it to the
     * SpriteComponent.
     *
     * @param sc
     */
    public Player(SpriteComponent sc) {
        super(sc);
        initialPic = new Picture("Ship.png");

        setPicture(initialPic);
        Dimension d = sc.getSize();
        setX(d.width/2);
        setY((d.height-100));
        setVelX(0);
        setVelY(0);
    }

    public void turn(double incr) {
        double heading = Math.atan2(getVelY(),getVelX());
        heading += incr;
        setVelY(Math.sin(heading));
        setVelX(Math.cos(heading));
        setPicture(initialPic.rotate(heading));
    }

    /**
     * This sprite only reacts to collisions with the
     * borders of the display region. When it does, it
     * wraps to the other side.
     * @param se
     */
    @Override
    public void processEvent(SpriteCollisionEvent se) {
        SpriteComponent sc = getSpriteComponent();
        if (se.xlo) {
            setX(sc.getSize().width-getWidth());
        }
        if (se.xhi) {
            setX(0);
        }
        if (se.ylo) {
            setY(sc.getSize().height-getHeight());
        }
        if (se.yhi) {
            setY(0);
        }
    }
}

